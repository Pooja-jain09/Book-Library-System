function toggleForms() {
    var signUpForm = document.querySelector('.sign-up-form');
    var signInForm = document.querySelector('.sign-in-form');
  
    if (signUpForm.style.display === 'none') {
      signUpForm.style.display = 'block';
      signInForm.style.display = 'none';
    } else {
      signUpForm.style.display = 'none';
      signInForm.style.display = 'block';
    }
  }
  const myLibrary = [];

const titleInput = document.querySelector('#book-title');
const authorInput = document.querySelector('#author-name');
const pagesInput = document.querySelector('#pages-number');
const readInput = document.querySelector('#read-check');
const addNewBookBtn = document.querySelector('#add-book');
const removeAllBooksBtn = document.querySelector('#remove-all');
const bookContainer = document.querySelector('#book-information');
const table = document.querySelector('#lib-table');
const titleErrorMessage = document.querySelector('.title-input .error-message');
const authorErrorMessage = document.querySelector('.author-input .error-message');
const pagesErrorMessage = document.querySelector('.pages-input .error-message');

// Event Listeners
addNewBookBtn.addEventListener('click', addBookToLibrary);
removeAllBooksBtn.addEventListener('click', removeAllBooks);
hamburgerMenu.addEventListener('click', () => {
  hamburgerMenu.classList.toggle('active');
  navMenu.classList.toggle('active');
})

class Book {
  constructor(title, author, pages, read) {
  this.title = title;
  this.author = author;
  this.pages = pages;
  this.read = read;

}
  getInfo() {
    const readStatus = this.read ? 'read' : 'not read';
    return `${this.title} by ${this.author}, ${this.pages} pages, ${readStatus}.`;
  }
}

// Testing if the method getInfo() from class Book, works properly as intended.
const testBook1 = new Book('Harry Potter and the Philosopher\'s Stone', 'J.K Rowling', 342, true);
const testBook2 = new Book('Eloquent JavaScript', 'Marijin', 380, false);
console.log(testBook1.getInfo());
console.log(testBook2.getInfo());

function addBookToLibrary() {
  table.append(tableBody);
  title = titleInput.value;
  author = authorInput.value;
  pages = pagesInput.value;
  read = readInput.checked;

  if (!validateFormBooks()) {
    return;
  }
  
  let newBook = new Book(title, author, pages, read);
  myLibrary.push(newBook);
  displayLibrary();
  resetAllInputs();
}

function displayLibrary() {
  tableBody.textContent = '';
  myLibrary.forEach((book, index) => {
    const newRow = document.createElement('tr');
    newRow.classList.add('body-row');

    const titleCell = document.createElement('td');
    titleCell.classList.add('body-cell');
    titleCell.textContent = book.title;

    const authorCell = document.createElement('td');
    authorCell.classList.add('body-cell');
    authorCell.textContent = book.author;

    const pagesCell = document.createElement('td');
    pagesCell.classList.add('body-cell');
    pagesCell.textContent = book.pages;

    const statusCell = document.createElement('td');
    statusCell.classList.add('body-cell');
    const readBtn = document.createElement('button');
    readBtn.classList.add('read-status-btn');

    if (book.read) {
     statusCell.textContent = 'Read ';
     readBtn.style.backgroundColor = 'green';
     readBtn.style.color = 'white';
     readBtn.innerHTML = '✓';
    } else if (!book.read) {
      statusCell.textContent = 'Not read ';
      readBtn.style.backgroundColor = 'red';
    }

    const removeCell = document.createElement('td');
    removeCell.classList.add('body-cell');
    const removeBookBtn = document.createElement('button');
    removeBookBtn.classList.add('remove-book-btn');
    removeBookBtn.innerHTML = '🞬';

    readBtn.addEventListener('click', () => toggleReadStatus(index));
    removeBookBtn.addEventListener('click', () => removeBook(index));

    statusCell.append(readBtn);
    removeCell.append(removeBookBtn);
    newRow.append(titleCell);
    newRow.append(authorCell);
    newRow.append(pagesCell);
    newRow.append(statusCell);
    newRow.append(removeCell);
    tableBody.append(newRow);
  });
}

// Utility Functions
function resetAllInputs() {
  titleInput.value = '';
  authorInput.value = '';
  pagesInput.value = '';
  readInput.checked = false;
  titleErrorMessage.textContent = '';
  authorErrorMessage.textContent = '';
  pagesErrorMessage.textContent = '';
}

function validateFormBooks() {
  const title = titleInput.value;
  const author = authorInput.value;
  const pages = parseInt(pagesInput.value);
  let isValid = true;

  if (!title) {
    showError(titleErrorMessage, 'Please give a valid title of the book');
    isValid = false;
  }   

  if (!author) {
    showError(authorErrorMessage, 'Please give a valid author');
    isValid = false;
  }

  if (!pages || isNaN(pages) || pages <= 0) {
    showError(pagesErrorMessage, 'Please give a valid number of pages');
    isValid = false;
  }
  return isValid;
}

function removeAllBooks() {
  tableBody.textContent = '';
  myLibrary.length = 0;
  resetAllInputs();
}

function toggleReadStatus(index) {
  myLibrary[index].read = !myLibrary[index].read;
  displayLibrary();
}

function removeBook(index) {
  myLibrary.splice(index, 1);
  displayLibrary();
}

function showError(errorElement, message) {
  errorElement.textContent = message;
}

// Default book instance example
const defaultBook1 = new Book('Chaos', 'James Gleick', 368, false);
const defaultBook2 = new Book('The Fellowship of the Ring', 'J.R.R Tolkien', 423, true);
myLibrary.push(defaultBook1, defaultBook2);
displayLibrary();



// IMAGE SHOWN

function displayLibrary() {
  tableBody.textContent = '';
  myLibrary.forEach((book, index) => {
    const newRow = document.createElement('tr');
    newRow.classList.add('body-row');

    // Create a cell for the book image
    const imageCell = document.createElement('td');
    imageCell.classList.add('body-cell');
    const bookImage = document.createElement('img');
    bookImage.src = 'path/to/book/image'; // Add the path to your book image here
    bookImage.alt = 'Book Cover';
    bookImage.classList.add('book-image');
    imageCell.appendChild(bookImage);

    const titleCell = document.createElement('td');
    titleCell.classList.add('body-cell');
    titleCell.textContent = book.title;

    const authorCell = document.createElement('td');
    authorCell.classList.add('body-cell');
    authorCell.textContent = book.author;

    const pagesCell = document.createElement('td');
    pagesCell.classList.add('body-cell');
    pagesCell.textContent = book.pages;

    const statusCell = document.createElement('td');
    statusCell.classList.add('body-cell');
    const readBtn = document.createElement('button');
    readBtn.classList.add('read-status-btn');

    if (book.read) {
      statusCell.textContent = 'Read ';
      readBtn.style.backgroundColor = 'green';
      readBtn.style.color = 'white';
      readBtn.innerHTML = '✓';
    } else if (!book.read) {
      statusCell.textContent = 'Not read ';
      readBtn.style.backgroundColor = 'red';
    }

    const removeCell = document.createElement('td');
    removeCell.classList.add('body-cell');
    const removeBookBtn = document.createElement('button');
    removeBookBtn.classList.add('remove-book-btn');
    removeBookBtn.innerHTML = '🞬';

    readBtn.addEventListener('click', () => toggleReadStatus(index));
    removeBookBtn.addEventListener('click', () => removeBook(index));

    statusCell.append(readBtn);
    removeCell.append(removeBookBtn);
    newRow.append(imageCell); // Append the image cell
    newRow.append(titleCell);
    newRow.append(authorCell);
    newRow.append(pagesCell);
    newRow.append(statusCell);
    newRow.append(removeCell);
    tableBody.append(newRow);
  });
}


// IMAGE SHOWN

// JavaScript

const bookImageInput = document.getElementById('book-image');
const previewImage = document.getElementById('preview-image');
const imageErrorMessage = document.querySelector('.image-input .error-message');

// Event listener for file input change
bookImageInput.addEventListener('change', function() {
  const file = this.files[0];

  if (file) {
    const reader = new FileReader();

    reader.onload = function() {
      previewImage.src = reader.result;
    };

    reader.readAsDataURL(file);
    imageErrorMessage.textContent = ''; // Clear error message
  } else {
    previewImage.src = '#';
  }
});
