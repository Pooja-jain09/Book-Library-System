const bookController = require("./book.controller");
const userController = require("./user.controller");
const samplebooksController = require("./samplebooks.controller");
const aboutController = require("./about.controller")

module.exports = {
    bookController,
    userController,
    samplebooksController,
    aboutController
}